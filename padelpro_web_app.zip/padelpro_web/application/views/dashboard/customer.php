<?php $this->load->view('templates/header'); ?>
<h2>Dashboard Pelanggan</h2>
<p>Selamat datang di PadelPro. Gunakan menu untuk melakukan booking lapangan.</p>
<?php $this->load->view('templates/footer'); ?>