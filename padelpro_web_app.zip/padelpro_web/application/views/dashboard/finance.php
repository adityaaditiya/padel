<?php $this->load->view('templates/header'); ?>
<h2>Dashboard Admin Keuangan</h2>
<p>Gunakan menu Keuangan untuk melihat laporan pendapatan booking dan penjualan.</p>
<?php $this->load->view('templates/footer'); ?>