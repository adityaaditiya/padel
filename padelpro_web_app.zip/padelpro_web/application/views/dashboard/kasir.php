<?php $this->load->view('templates/header'); ?>
<h2>Dashboard Kasir</h2>
<p>Selamat datang, kasir. Anda dapat memproses pembayaran booking dan penjualan F&B melalui menu POS.</p>
<?php $this->load->view('templates/footer'); ?>