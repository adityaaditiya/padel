<?php $this->load->view('templates/header'); ?>
<h2>Dashboard Owner</h2>
<p>Selamat datang, pemilik. Anda dapat mengelola data master, melihat laporan bisnis, dan memonitor aktivitas harian.</p>
<?php $this->load->view('templates/footer'); ?>